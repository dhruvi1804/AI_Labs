Search and A* Lab Solution
==========================

Files:
- search_astar_lab_solution.ipynb : explanations, tasks, and runnable experiments
- search_astar_lab_solution.py    : standalone A* and BFS implementation plus tests
- search_astar_lab_report.pdf     : written report and reflection answers

Run:
    python search_astar_lab_solution.py

Requires Python 3 only; no third-party packages.

Expansion-count convention:
A state is counted as expanded when removed from the frontier and its neighbours
are generated. The goal is tested before expansion, so the goal itself is not counted.
