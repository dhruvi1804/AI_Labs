"""
Search and A* Lab — Warehouse Robot Navigation
Python 3 standard library only.

Run:
    python search_astar_lab_solution.py

The script runs:
- original warehouse with BFS and A* (Manhattan, h=0, Euclidean, 2x Manhattan)
- trivial, no-solution, and alternative-path tests
- prints path lengths, expanded-state counts, and validation checks
"""

from collections import deque
import heapq
import math

WAREHOUSE = [
    "#################",
    "#S....#.........#",
    "#.###.#.#######.#",
    "#...#.#.......#.#",
    "###.#.#######.#.#",
    "#...#.........#.#",
    "#.###########.#.#",
    "#.............#G#",
    "#################",
]

TRIVIAL_MAP = [
    "#####",
    "#SG##",
    "#####",
]

NO_SOLUTION_MAP = [
    "#######",
    "#S....#",
    "###.###",
    "#...#G#",
    "#######",
]

ALTERNATIVE_PATHS_MAP = [
    "#######",
    "#S...G#",
    "#.....#",
    "#######",
]

# Deterministic neighbour order makes the chosen path reproducible.
ACTIONS = [
    ("Up", -1, 0),
    ("Down", 1, 0),
    ("Left", 0, -1),
    ("Right", 0, 1),
]


def locate(grid, marker):
    """Find marker and return its (row, column) coordinate."""
    for r, row in enumerate(grid):
        for c, cell in enumerate(row):
            if cell == marker:
                return (r, c)
    raise ValueError(f"Map is missing marker {marker!r}")


def validate_grid(grid):
    """Check rectangular map and exactly one S and G."""
    if not grid or not grid[0]:
        raise ValueError("Grid must not be empty.")
    width = len(grid[0])
    if any(len(row) != width for row in grid):
        raise ValueError("All grid rows must have the same width.")
    if sum(row.count("S") for row in grid) != 1:
        raise ValueError("Grid must contain exactly one S.")
    if sum(row.count("G") for row in grid) != 1:
        raise ValueError("Grid must contain exactly one G.")
    if any(ch not in "#.SG" for row in grid for ch in row):
        raise ValueError("Grid contains an unsupported symbol.")


def neighbours(grid, state):
    """Yield (next_state, action_name) for legal moves."""
    rows, cols = len(grid), len(grid[0])
    r, c = state
    for name, dr, dc in ACTIONS:
        nxt = (r + dr, c + dc)
        nr, nc = nxt
        if 0 <= nr < rows and 0 <= nc < cols and grid[nr][nc] != "#":
            yield nxt, name


def reconstruct_path(parent, goal):
    """Follow predecessor links from goal back to the start."""
    path = []
    current = goal
    while current is not None:
        path.append(current)
        current = parent[current]
    return list(reversed(path))


def breadth_first_search(grid):
    """BFS baseline: shortest path when every move has unit cost."""
    validate_grid(grid)
    start, goal = locate(grid, "S"), locate(grid, "G")
    frontier = deque([start])
    parent = {start: None}
    expanded = 0

    while frontier:
        current = frontier.popleft()
        if current == goal:
            return reconstruct_path(parent, goal), expanded

        expanded += 1
        for nxt, _action in neighbours(grid, current):
            if nxt not in parent:
                parent[nxt] = current
                frontier.append(nxt)

    return None, expanded


def make_heuristic(goal, kind):
    """Return h(n) for the selected heuristic experiment."""
    def h(state):
        dx = abs(state[0] - goal[0])
        dy = abs(state[1] - goal[1])
        if kind == "manhattan":
            return dx + dy
        if kind == "zero":
            return 0
        if kind == "euclidean":
            return math.sqrt(dx * dx + dy * dy)
        if kind == "double_manhattan":
            return 2 * (dx + dy)
        raise ValueError(f"Unknown heuristic: {kind}")
    return h


def a_star_search(grid, heuristic_kind="manhattan"):
    """
    A* using a min-heap priority queue.
    f(n) = g(n) + h(n); each transition costs 1.
    Returns (path, expanded_count), or (None, expanded_count).
    """
    validate_grid(grid)
    start, goal = locate(grid, "S"), locate(grid, "G")
    h = make_heuristic(goal, heuristic_kind)

    # Heap entries: (f score, insertion order, g score, state).
    # The insertion counter provides deterministic tie-breaking.
    frontier = []
    insertion_order = 0
    heapq.heappush(frontier, (h(start), insertion_order, 0, start))

    parent = {start: None}
    best_g = {start: 0}
    closed = set()
    expanded = 0

    while frontier:
        f_score, _order, g_score, current = heapq.heappop(frontier)

        # Ignore stale heap entries and states already expanded.
        if current in closed or g_score != best_g.get(current):
            continue

        if current == goal:
            return reconstruct_path(parent, goal), expanded

        closed.add(current)
        expanded += 1

        for nxt, _action in neighbours(grid, current):
            tentative_g = g_score + 1
            if tentative_g < best_g.get(nxt, float("inf")):
                best_g[nxt] = tentative_g
                parent[nxt] = current
                insertion_order += 1
                f_nxt = tentative_g + h(nxt)
                heapq.heappush(
                    frontier,
                    (f_nxt, insertion_order, tentative_g, nxt)
                )

    return None, expanded


def path_is_valid(grid, path):
    """Validate bounds, obstacle avoidance, and one-cell moves."""
    if path is None:
        return False
    if path[0] != locate(grid, "S") or path[-1] != locate(grid, "G"):
        return False
    for r, c in path:
        if not (0 <= r < len(grid) and 0 <= c < len(grid[0])):
            return False
        if grid[r][c] == "#":
            return False
    for a, b in zip(path, path[1:]):
        if abs(a[0] - b[0]) + abs(a[1] - b[1]) != 1:
            return False
    return True


def path_actions(path):
    """Convert consecutive coordinates into Up/Down/Left/Right labels."""
    names = {( -1, 0): "Up", (1, 0): "Down", (0, -1): "Left", (0, 1): "Right"}
    result = []
    for a, b in zip(path, path[1:]):
        result.append(names[(b[0] - a[0], b[1] - a[1])])
    return result


def print_result(label, grid, result):
    path, expanded = result
    if path is None:
        print(f"{label}: no solution; states expanded = {expanded}")
    else:
        print(f"{label}: solution found")
        print(f"  path length (moves): {len(path) - 1}")
        print(f"  states expanded: {expanded}")
        print(f"  valid path: {path_is_valid(grid, path)}")
        print(f"  path: {path}")
        print(f"  actions: {' -> '.join(path_actions(path))}")


def run_original_experiments():
    print("=" * 68)
    print("ORIGINAL WAREHOUSE")
    print("\n".join(WAREHOUSE))
    bfs_result = breadth_first_search(WAREHOUSE)
    print_result("BFS", WAREHOUSE, bfs_result)

    heuristic_results = {}
    for kind, label in [
        ("manhattan", "A* Manhattan"),
        ("zero", "A* h=0"),
        ("euclidean", "A* Euclidean"),
        ("double_manhattan", "A* 2 x Manhattan"),
    ]:
        result = a_star_search(WAREHOUSE, kind)
        heuristic_results[label] = result
        print_result(label, WAREHOUSE, result)

    print("\nCOMPARISON TABLE")
    print(f"{'Algorithm':<22} {'Found':<8} {'Length':<8} {'Expanded':<10}")
    all_results = [("BFS", bfs_result)] + list(heuristic_results.items())
    for label, (path, expanded) in all_results:
        length = len(path) - 1 if path else "-"
        print(f"{label:<22} {str(path is not None):<8} {str(length):<8} {expanded:<10}")


def run_test_cases():
    print("\n" + "=" * 68)
    print("SYSTEMATIC TESTS")

    for label, grid, expected_length in [
        ("Trivial adjacent goal", TRIVIAL_MAP, 1),
        ("No-solution map", NO_SOLUTION_MAP, None),
        ("Alternative paths", ALTERNATIVE_PATHS_MAP, 4),
    ]:
        print(f"\n{label}:")
        print("\n".join(grid))
        result = a_star_search(grid, "manhattan")
        print_result("A*", grid, result)
        path, _ = result
        actual = len(path) - 1 if path else None
        print(f"  expected length: {expected_length}")
        print(f"  test passed: {actual == expected_length}")


if __name__ == "__main__":
    run_original_experiments()
    run_test_cases()
