"""
Warehouse Navigation — Goal-Based Agent
Uses Breadth-First Search (BFS) to find a shortest collision-free path
on the unweighted four-neighbour grid from S to G.

Run:
    python warehouse_goal_agent.py
Requirements: Python 3.x only (no external packages).
"""

from collections import deque

WAREHOUSE = [
    "#####################",
    "#S....#............G#",
    "#.##....##########..#",
    "#....##.............#",
    "#.######.###.#.###..#",
    "#........#..........#",
    "#####################",
]

# Each action changes the row/column by exactly one cell.
ACTIONS = {
    "Up": (-1, 0),
    "Down": (1, 0),
    "Left": (0, -1),
    "Right": (0, 1),
}


def find_marker(grid, marker):
    """Return the (row, column) position of S or G."""
    for row, line in enumerate(grid):
        for col, cell in enumerate(line):
            if cell == marker:
                return row, col
    raise ValueError(f"Map does not contain marker {marker!r}")


def breadth_first_search(grid, start, goal):
    """
    Return a shortest path and its action sequence, or (None, None).
    BFS explores states in increasing number of moves. A predecessor
    dictionary prevents revisiting cells and reconstructs the path.
    """
    rows, cols = len(grid), len(grid[0])
    frontier = deque([start])
    predecessor = {start: None}
    action_used = {}

    while frontier:
        current = frontier.popleft()

        if current == goal:
            break

        for action, (dr, dc) in ACTIONS.items():
            nxt = (current[0] + dr, current[1] + dc)

            in_bounds = 0 <= nxt[0] < rows and 0 <= nxt[1] < cols
            if not in_bounds:
                continue
            if grid[nxt[0]][nxt[1]] == "#":
                continue
            if nxt in predecessor:
                continue

            predecessor[nxt] = current
            action_used[nxt] = action
            frontier.append(nxt)

    if goal not in predecessor:
        return None, None

    path = []
    actions = []
    current = goal
    while current is not None:
        path.append(current)
        if current != start:
            actions.append(action_used[current])
        current = predecessor[current]

    path.reverse()
    actions.reverse()
    return path, actions


def display_path(grid, path):
    """Print the map with * marking the route (S and G are retained)."""
    route_cells = set(path)
    for r, line in enumerate(grid):
        rendered = []
        for c, cell in enumerate(line):
            if (r, c) in route_cells and cell not in ("S", "G"):
                rendered.append("*")
            else:
                rendered.append(cell)
        print("".join(rendered))


def main():
    # The map is the environment; the current coordinate is the state.
    start = find_marker(WAREHOUSE, "S")
    goal = find_marker(WAREHOUSE, "G")

    path, actions = breadth_first_search(WAREHOUSE, start, goal)

    print("WAREHOUSE MAP")
    print("\n".join(WAREHOUSE))
    print(f"\nStart: {start}; Goal: {goal}")

    if path is None:
        print("No collision-free path exists.")
        return

    print("\nShortest path found using Breadth-First Search (BFS).")
    print(f"Number of moves: {len(actions)}")
    print("Action sequence:")
    print(" -> ".join(actions))
    print("\nPath coordinates (row, column):")
    print(path)
    print("\nMap with path marked by *:")
    display_path(WAREHOUSE, path)


if __name__ == "__main__":
    main()
