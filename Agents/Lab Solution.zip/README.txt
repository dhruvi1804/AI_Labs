Warehouse Agents Lab Solution
==============================

Files:
- warehouse_agents_lab_solution.ipynb : explanations and runnable code
- warehouse_goal_agent.py             : standalone Python 3 implementation
- warehouse_agents_lab_report.pdf     : report answering the lab tasks

Run:
    python warehouse_goal_agent.py

No external Python packages are required. The implementation uses Breadth-First Search
because every move has equal cost and BFS returns a shortest path on this finite grid.
