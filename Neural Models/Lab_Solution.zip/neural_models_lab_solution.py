"""
Neural Models Lab Exercise — complete reference implementation
Requirements: Python 3, NumPy, PyTorch (CPU is sufficient).
Run: python neural_models_lab_solution.py
"""
import torch
import numpy as np

torch.set_printoptions(precision=6, sci_mode=False)
torch.manual_seed(42)

X = torch.tensor([[0., 0.], [0., 1.], [1., 0.], [1., 1.]])
y_binary = torch.tensor([[0.], [1.], [1.], [0.]])

def build_binary_model(activation="sigmoid"):
    activations = {
        "sigmoid": torch.nn.Sigmoid(),
        "tanh": torch.nn.Tanh(),
        "relu": torch.nn.ReLU(),
    }
    return torch.nn.Sequential(
        torch.nn.Linear(2, 2),
        activations[activation],
        torch.nn.Linear(2, 1),  # one logit; sigmoid is applied by the loss/prediction
    )

def train_binary(activation="sigmoid", steps=5000, learning_rate=0.05,
                 seed=42, zero_init=False, print_results=True):
    torch.manual_seed(seed)
    model = build_binary_model(activation)
    if zero_init:
        # Set weights AND biases to zero so the hidden units are exactly symmetric.
        with torch.no_grad():
            for parameter in model.parameters():
                parameter.zero_()

    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
    criterion = torch.nn.BCEWithLogitsLoss()
    initial_loss = criterion(model(X), y_binary).item()
    first_layer_gradient = None

    for step in range(steps):
        optimizer.zero_grad()
        logits = model(X)              # forward pass
        loss = criterion(logits, y_binary)  # scalar batch loss
        loss.backward()                # reverse-mode automatic differentiation
        if step == 0:
            first_layer_gradient = model[0].weight.grad.detach().clone()
        optimizer.step()                # parameter update

    with torch.no_grad():
        logits = model(X)
        probabilities = torch.sigmoid(logits)
        predictions = (probabilities >= 0.5).int()
        final_loss = criterion(logits, y_binary).item()

    if print_results:
        print(f"Activation: {activation}")
        print(f"Initial loss: {initial_loss:.8f}")
        print(f"Final loss:   {final_loss:.8f}")
        print("Probabilities:", probabilities.flatten().tolist())
        print("Predictions:  ", predictions.flatten().tolist())
        print("First-layer weight gradient after first backward():")
        print(first_layer_gradient)
        print("All four correct:", bool(torch.equal(predictions, y_binary.int())))
        print()
    return model, initial_loss, final_loss, probabilities, predictions, first_layer_gradient

if __name__ == "__main__":
    print("TASK 4 — BINARY XOR AND ACTIVATION EXPERIMENT")
    results = {}
    for activation in ["sigmoid", "tanh", "relu"]:
        results[activation] = train_binary(activation=activation)

    print("TASK 4 — ZERO INITIALISATION SYMMETRY EXPERIMENT")
    torch.manual_seed(42)
    symmetric_model = build_binary_model("sigmoid")
    with torch.no_grad():
        for parameter in symmetric_model.parameters():
            parameter.zero_()
    optimizer = torch.optim.Adam(symmetric_model.parameters(), lr=0.05)
    criterion = torch.nn.BCEWithLogitsLoss()
    for step in range(101):
        if step in [0, 1, 2, 10, 100]:
            print(f"Step {step}: first-layer rows =")
            print(symmetric_model[0].weight.detach())
        optimizer.zero_grad()
        loss = criterion(symmetric_model(X), y_binary)
        loss.backward()
        optimizer.step()
    with torch.no_grad():
        probs = torch.sigmoid(symmetric_model(X))
        print("Zero-init final loss:", criterion(symmetric_model(X), y_binary).item())
        print("Zero-init probabilities:", probs.flatten().tolist())
        print("Zero-init predictions:", (probs >= 0.5).int().flatten().tolist())

    print("\\nTASK 5 — THREE-CLASS EXTENSION")
    # Class 0: (0,0); Class 1: disagreement; Class 2: (1,1)
    y_multi = torch.tensor([0, 1, 1, 2], dtype=torch.long)
    torch.manual_seed(42)
    multi_model = torch.nn.Sequential(
        torch.nn.Linear(2, 2),
        torch.nn.Sigmoid(),
        torch.nn.Linear(2, 3),  # three logits per example
    )
    optimizer = torch.optim.Adam(multi_model.parameters(), lr=0.05)
    criterion = torch.nn.CrossEntropyLoss()
    initial_loss = criterion(multi_model(X), y_multi).item()
    for _ in range(5000):
        optimizer.zero_grad()
        logits = multi_model(X)
        loss = criterion(logits, y_multi)  # CrossEntropyLoss expects raw logits
        loss.backward()
        optimizer.step()

    with torch.no_grad():
        logits = multi_model(X)
        probabilities = torch.softmax(logits, dim=1)
        predictions = probabilities.argmax(dim=1)
        print(f"Initial multiclass loss: {initial_loss:.8f}")
        print(f"Final multiclass loss:   {criterion(logits, y_multi).item():.8f}")
        print("Rows are inputs (00, 01, 10, 11); columns are classes (0, 1, 2):")
        print(probabilities)
        print("Predicted classes:", predictions.tolist())
        print("Probability row sums:", probabilities.sum(dim=1).tolist())

        # Numerical p-y demonstration for one example:
        # For one-hot target y, dL/d(logits) = p - y.
        with torch.enable_grad():
            one_logits = logits[1:2].detach().clone().requires_grad_(True)
            one_target = y_multi[1:2]
            one_loss = torch.nn.functional.cross_entropy(one_logits, one_target)
            one_loss.backward()
            p = torch.softmax(one_logits.detach(), dim=1)
            one_hot = torch.nn.functional.one_hot(one_target, num_classes=3).float()
            print("Example (0,1) p:", p)
            print("Example (0,1) one-hot y:", one_hot)
            print("Autograd dL/dlogits:", one_logits.grad)
            print("p - y:", p - one_hot)

        shifted = torch.softmax(logits[1] + 100.0, dim=0)
        print("Softmax unchanged after adding 100:", shifted)
