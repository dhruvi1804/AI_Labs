Neural Models Lab Solution
===========================

Files:
- neural_models_lab_solution.ipynb : notebook with task explanations and runnable experiments
- neural_models_lab_solution.py   : standalone Python implementation
- neural_models_lab_report.pdf    : written report, experiment results, and reflection answers

Requirements:
    python -m pip install torch numpy

Run the script:
    python neural_models_lab_solution.py

The reference results use PyTorch CPU, seed 42, Adam learning rate 0.05, and 5,000 full-batch steps. Numerical results may vary slightly across versions/platforms. The activation comparison is one experimental run, not a universal ranking.
