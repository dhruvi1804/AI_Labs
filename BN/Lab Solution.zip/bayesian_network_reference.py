"""
Building and Learning a Bayesian Network — reference solution.

Pure-Python reference implementation of the Sprinkler / WetGrass network.
It independently verifies exact inference by enumeration, demonstrates
MLE and BDeu-style Bayesian parameter estimation, and runs semantic checks.

The accompanying notebook also contains the pgmpy implementation requested
by the supplied lab. Install pgmpy, pandas, numpy, and matplotlib to run it.
This script itself needs only Python 3.
"""
from itertools import product
import random

# Variables are binary: 0=False, 1=True.
NODES = {"Cloudy", "Rain", "Sprinkler", "WetGrass"}
EDGES = {
    ("Cloudy", "Rain"),
    ("Cloudy", "Sprinkler"),
    ("Rain", "WetGrass"),
    ("Sprinkler", "WetGrass"),
}
WET_TRUE = {
    (0, 0): 0.01,
    (0, 1): 0.90,
    (1, 0): 0.90,
    (1, 1): 0.99,
}


def p_cloudy(c):
    return 0.5


def p_rain(r, c):
    p = {0: 0.2, 1: 0.8}[c]
    return p if r == 1 else 1 - p


def p_sprinkler(s, c):
    p = {0: 0.5, 1: 0.1}[c]
    return p if s == 1 else 1 - p


def p_wetgrass(w, r, s):
    p = WET_TRUE[(r, s)]
    return p if w == 1 else 1 - p


def joint_probability(c, r, s, w):
    """P(C,R,S,W)=P(C)P(R|C)P(S|C)P(W|R,S)."""
    return (
        p_cloudy(c)
        * p_rain(r, c)
        * p_sprinkler(s, c)
        * p_wetgrass(w, r, s)
    )


ASSIGNMENTS = list(product((0, 1), repeat=4))


def enumerate_posterior(query_index, evidence):
    """Exact posterior for one variable using all 16 joint assignments."""
    denominator = 0.0
    numerator = 0.0
    for assignment in ASSIGNMENTS:
        c, r, s, w = assignment
        if any(assignment[idx] != value for idx, value in evidence.items()):
            continue
        weight = joint_probability(c, r, s, w)
        denominator += weight
        if assignment[query_index] == 1:
            numerator += weight
    if denominator == 0:
        raise ValueError("Evidence has zero probability.")
    return numerator / denominator


def run_exact_inference():
    print("EXACT INFERENCE BY ENUMERATION")
    p_r_w = enumerate_posterior(1, {3: 1})
    p_s_w = enumerate_posterior(2, {3: 1})
    p_c_w = enumerate_posterior(0, {3: 1})
    p_r_w_s0 = enumerate_posterior(1, {3: 1, 2: 0})
    print(f"P(Rain=1 | WetGrass=1) = {p_r_w:.12f}")
    print(f"P(Sprinkler=1 | WetGrass=1) = {p_s_w:.12f}")
    print(f"P(Cloudy=1 | WetGrass=1) = {p_c_w:.12f}")
    print(f"P(Rain=1 | WetGrass=1, Sprinkler=0) = {p_r_w_s0:.12f}")
    return p_r_w


def sample_network(n, seed):
    """Generate complete samples in topological order C, R, S, W."""
    rng = random.Random(seed)
    rows = []
    for _ in range(n):
        c = int(rng.random() < 0.5)
        r = int(rng.random() < {0: 0.2, 1: 0.8}[c])
        s = int(rng.random() < {0: 0.5, 1: 0.1}[c])
        w = int(rng.random() < WET_TRUE[(r, s)])
        rows.append((c, r, s, w))
    return rows


def mle_conditional(data, child_index, parent_index, parent_value):
    """MLE P(child=1 | parent=parent_value) from complete observations."""
    selected = [row for row in data if row[parent_index] == parent_value]
    if not selected:
        return float("nan")
    return sum(row[child_index] for row in selected) / len(selected)


def bdeu_binary_conditional(data, child_index, parent_index,
                            parent_value, equivalent_sample_size=10):
    """
    Binary one-parent BDeu posterior predictive mean.
    For a binary child and binary parent, each of the 4 CPT cells receives
    alpha = ESS / (2 child states * 2 parent configurations).
    """
    alpha = equivalent_sample_size / 4.0
    selected = [row for row in data if row[parent_index] == parent_value]
    true_count = sum(row[child_index] == 1 for row in selected)
    false_count = sum(row[child_index] == 0 for row in selected)
    return (true_count + alpha) / (true_count + false_count + 2 * alpha)


def run_parameter_estimation():
    print("\nMAXIMUM-LIKELIHOOD ESTIMATION")
    data_1000 = sample_network(1000, seed=7)
    manual = mle_conditional(data_1000, child_index=1, parent_index=0,
                             parent_value=1)
    print(f"Manual MLE P(Rain=1 | Cloudy=1), N=1000: {manual:.12f}")
    print("True parameter:", 0.8)

    print("\nSAMPLE-SIZE EXPERIMENT")
    print(f"{'N':>6} {'MLE estimate':>16} {'absolute error':>16}")
    estimates = []
    for n in [20, 50, 100, 500, 1000, 5000]:
        estimate = mle_conditional(
            sample_network(n, seed=7), 1, 0, 1
        )
        estimates.append(estimate)
        print(f"{n:6d} {estimate:16.6f} {abs(estimate - 0.8):16.6f}")

    print("\nSPARSE-DATA MLE VS BDeu-STYLE ESTIMATE (N=30, seed=11)")
    small = sample_network(30, seed=11)
    mle = mle_conditional(small, 1, 0, 1)
    bayes = bdeu_binary_conditional(
        small, 1, 0, 1, equivalent_sample_size=10
    )
    print(f"True parameter: {0.8:.6f}")
    print(f"MLE:            {mle:.6f}")
    print(f"BDeu estimate:  {bayes:.6f}")

    print("\nREPEATED DATASETS (N=100, different seeds)")
    for seed in [1, 2, 3, 4, 5]:
        estimate = mle_conditional(sample_network(100, seed), 1, 0, 1)
        print(f"seed={seed}: {estimate:.6f}")


def validate_model_specification():
    """Tests structure and probability normalization at the specification level."""
    assert NODES == {"Cloudy", "Rain", "Sprinkler", "WetGrass"}
    assert EDGES == {
        ("Cloudy", "Rain"),
        ("Cloudy", "Sprinkler"),
        ("Rain", "WetGrass"),
        ("Sprinkler", "WetGrass"),
    }
    assert abs(sum(p_cloudy(c) for c in (0, 1)) - 1) < 1e-12
    for c in (0, 1):
        assert abs(sum(p_rain(r, c) for r in (0, 1)) - 1) < 1e-12
        assert abs(sum(p_sprinkler(s, c) for s in (0, 1)) - 1) < 1e-12
    for r, s in product((0, 1), repeat=2):
        assert abs(sum(p_wetgrass(w, r, s) for w in (0, 1)) - 1) < 1e-12
    assert abs(enumerate_posterior(1, {3: 1}) - 0.7047692307692307) < 1e-12
    print("All independent reference-model tests passed.")


if __name__ == "__main__":
    validate_model_specification()
    run_exact_inference()
    run_parameter_estimation()
