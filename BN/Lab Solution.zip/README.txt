Bayesian Network Lab — Solution Package
========================================

Files:
- bayesian_network_lab_solution.ipynb : completed pgmpy notebook
- bayesian_network_reference.py       : independent, runnable pure-Python reference
- bayesian_network_lab_report.pdf      : concise report and numerical inference results

Notebook requirements:
    Python 3
    pgmpy >= 1.0
    numpy
    pandas
    matplotlib

Install (inside a notebook cell if needed):
    %pip install -q "pgmpy>=1.0" numpy pandas matplotlib

The notebook includes prompts and inspected candidate code. It deliberately does not
download/load a multi-gigabyte local Qwen model; the model is optional and not required
for the Bayesian-network tasks.

Run the independent reference script:
    python bayesian_network_reference.py

The reference script uses only the Python standard library. It independently enumerates
the 16 assignments for exact inference and demonstrates MLE/BDeu-style estimation.
Its random-sampler outputs are labelled separately from pgmpy's simulation outputs.
