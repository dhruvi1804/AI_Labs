% Optional Prolog component for the Logical Planning laboratory.
% Run with: swipl -s planner.pl
% Then try the queries listed in README.md.

% Warehouse connectivity facts
connected(a,b).
connected(b,a).
connected(b,c).
connected(c,b).

% A direct rule derived from connectivity
can_move(X,Y) :-
    connected(X,Y).

% Independent check for a proposed movement
valid_move(X,Y) :-
    connected(X,Y).

% Simple logical inference example
wet_road.
slippery :-
    wet_road.
reduce_speed :-
    slippery.
