"""
Logical Planning Lab: BFS planner and independent plan validator.

Run:
    python3 planner.py

The script solves:
  1. Warehouse package-delivery domain
  2. Locked-door navigation domain

It also runs the required solvable, impossible, and irrelevant-action tests,
plus locked-door validation checks.
"""

from collections import deque
from dataclasses import dataclass
from typing import FrozenSet, Iterable, Optional


@dataclass(frozen=True)
class Action:
    name: str
    positive_preconditions: FrozenSet[str] = frozenset()
    negative_preconditions: FrozenSet[str] = frozenset()
    add_effects: FrozenSet[str] = frozenset()
    delete_effects: FrozenSet[str] = frozenset()

    def applicable(self, state: FrozenSet[str]) -> bool:
        return (self.positive_preconditions <= state
                and not (self.negative_preconditions & state))

    def apply(self, state: FrozenSet[str]) -> FrozenSet[str]:
        if not self.applicable(state):
            raise ValueError(f"Action {self.name} is not applicable")
        return frozenset((state - self.delete_effects) | self.add_effects)


def breadth_first_search(initial: Iterable[str],
                         goal: Iterable[str],
                         actions: list[Action]):
    """Return (action plan, state trace), or (None, None) if no plan exists."""
    start = frozenset(initial)
    goal_set = frozenset(goal)
    queue = deque([(start, [], [start])])
    visited = {start}

    while queue:
        state, plan, trace = queue.popleft()
        if goal_set <= state:
            return plan, trace

        for action in actions:
            if action.applicable(state):
                next_state = action.apply(state)
                if next_state not in visited:
                    visited.add(next_state)
                    queue.append((next_state, plan + [action],
                                  trace + [next_state]))
    return None, None


def validate_plan(initial: Iterable[str], goal: Iterable[str],
                  actions: list[Action], proposed_names: list[str]):
    """Execute a named plan and report its first invalid step, if any."""
    state = frozenset(initial)
    by_name = {a.name: a for a in actions}
    trace = [state]

    for step, name in enumerate(proposed_names, start=1):
        if name not in by_name:
            return False, state, trace, (
                f"Step {step}: unknown action '{name}'")
        action = by_name[name]
        missing = action.positive_preconditions - state
        forbidden = action.negative_preconditions & state
        if missing or forbidden:
            details = []
            if missing:
                details.append("unsatisfied positive preconditions: "
                               + ", ".join(sorted(missing)))
            if forbidden:
                details.append("violated negative preconditions: "
                               + ", ".join(sorted(forbidden)))
            return False, state, trace, (
                f"Step {step} ({name}) is invalid; " + "; ".join(details))
        state = action.apply(state)
        trace.append(state)

    achieved = frozenset(goal) <= state
    if not achieved:
        return False, state, trace, "All actions were applicable, but the goal was not reached"
    return True, state, trace, "Valid plan; goal reached"


def show_result(title, initial, goal, actions):
    print(f"\n=== {title} ===")
    plan, trace = breadth_first_search(initial, goal, actions)
    print("Initial:", sorted(initial))
    print("Goal:", sorted(goal))
    if plan is None:
        print("No plan found")
        return None
    print("Plan:")
    for i, action in enumerate(plan, 1):
        print(f"  {i}. {action.name}")
    print("State trace:")
    for i, state in enumerate(trace):
        print(f"  S{i}: {sorted(state)}")
    return plan


def warehouse_actions(include_pickup=True, include_irrelevant=False):
    actions = [
        Action("Move(A,B)", frozenset({"At(Robot,A)"}),
               add_effects=frozenset({"At(Robot,B)"}),
               delete_effects=frozenset({"At(Robot,A)"})),
        Action("Move(B,A)", frozenset({"At(Robot,B)"}),
               add_effects=frozenset({"At(Robot,A)"}),
               delete_effects=frozenset({"At(Robot,B)"})),
        Action("Move(B,C)", frozenset({"At(Robot,B)"}),
               add_effects=frozenset({"At(Robot,C)"}),
               delete_effects=frozenset({"At(Robot,B)"})),
        Action("Move(C,B)", frozenset({"At(Robot,C)"}),
               add_effects=frozenset({"At(Robot,B)"}),
               delete_effects=frozenset({"At(Robot,C)"})),
        Action("Drop(Package,C)",
               frozenset({"At(Robot,C)", "Holding(Package)"}),
               add_effects=frozenset({"At(Package,C)"}),
               delete_effects=frozenset({"Holding(Package)"})),
    ]
    if include_pickup:
        actions.append(Action(
            "PickUp(Package,A)",
            frozenset({"At(Robot,A)", "At(Package,A)"}),
            add_effects=frozenset({"Holding(Package)"}),
            delete_effects=frozenset({"At(Package,A)"})))
        actions.append(Action(
            "PickUp(Package,B)",
            frozenset({"At(Robot,B)", "At(Package,B)"}),
            add_effects=frozenset({"Holding(Package)"}),
            delete_effects=frozenset({"At(Package,B)"})))
        actions.append(Action(
            "PickUp(Package,C)",
            frozenset({"At(Robot,C)", "At(Package,C)"}),
            add_effects=frozenset({"Holding(Package)"}),
            delete_effects=frozenset({"At(Package,C)"})))
    if include_irrelevant:
        # This action moves the robot only; it does not move or deliver the package.
        actions.append(Action(
            "RobotOnlyMove(A,B)",
            frozenset({"At(Robot,A)"}),
            add_effects=frozenset({"At(Robot,B)"}),
            delete_effects=frozenset({"At(Robot,A)"})))
    return actions


def locked_door_actions(include_pickkey=True):
    actions = [
        Action("Move(A,B)", frozenset({"At(A)"}),
               add_effects=frozenset({"At(B)"}),
               delete_effects=frozenset({"At(A)"})),
        Action("Move(B,A)", frozenset({"At(B)"}),
               add_effects=frozenset({"At(A)"}),
               delete_effects=frozenset({"At(B)"})),
        Action("Unlock", frozenset({"At(B)", "HasKey"}),
               add_effects=frozenset({"Unlocked"})),
        Action("Move(B,C)", frozenset({"At(B)", "Unlocked"}),
               add_effects=frozenset({"At(C)"}),
               delete_effects=frozenset({"At(B)"})),
        Action("Move(C,B)", frozenset({"At(C)", "Unlocked"}),
               add_effects=frozenset({"At(B)"}),
               delete_effects=frozenset({"At(C)"})),
    ]
    if include_pickkey:
        actions.insert(2, Action(
            "PickKey", frozenset({"At(A)", "KeyAt(A)"}),
            add_effects=frozenset({"HasKey"}),
            delete_effects=frozenset({"KeyAt(A)"})))
    return actions


def main():
    warehouse_initial = {"At(Robot,A)", "At(Package,A)"}
    warehouse_goal = {"At(Package,C)"}

    # Task 0: initially PickUp(Package,A) is applicable; Drop is not.
    wa = warehouse_actions()
    pickup = next(a for a in wa if a.name == "PickUp(Package,A)")
    drop = next(a for a in wa if a.name == "Drop(Package,C)")
    print("Task 0:")
    print("PickUp(Package,A) initially applicable:", pickup.applicable(frozenset(warehouse_initial)))
    print("Drop(Package,C) initially applicable:", drop.applicable(frozenset(warehouse_initial)))

    show_result("Warehouse: Test A (solvable)", warehouse_initial,
                warehouse_goal, wa)

    show_result("Warehouse: Test B (PickUp removed / impossible)",
                warehouse_initial, warehouse_goal,
                warehouse_actions(include_pickup=False))

    show_result("Warehouse: Test C (irrelevant robot-only action)",
                warehouse_initial, warehouse_goal,
                warehouse_actions(include_irrelevant=True))

    locked_initial = {"At(A)", "KeyAt(A)"}
    locked_goal = {"At(C)"}
    la = locked_door_actions()
    locked_plan = show_result("Locked door: BFS solution", locked_initial,
                              locked_goal, la)

    show_result("Locked door: PickKey removed",
                locked_initial, locked_goal,
                locked_door_actions(include_pickkey=False))

    # Task 6(d): validate the proposed sequence and show its first error.
    proposed = ["Move(A,B)", "Unlock", "Move(B,C)"]
    ok, final_state, trace, message = validate_plan(
        locked_initial, locked_goal, la, proposed)
    print("\nValidation of proposed locked-door sequence:")
    print(proposed)
    print(message)
    print("State at failure:", sorted(final_state))

    if locked_plan is not None:
        names = [a.name for a in locked_plan]
        ok, final_state, trace, message = validate_plan(
            locked_initial, locked_goal, la, names)
        print("\nIndependent validation of BFS locked-door plan:")
        print(message)


if __name__ == "__main__":
    main()
