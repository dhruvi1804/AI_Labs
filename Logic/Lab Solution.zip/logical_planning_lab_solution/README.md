# Logical Planning Lab — Complete Working Package

This folder contains a runnable breadth-first-search (BFS) planner, an independent
plan validator, a Prolog verifier, and a written solution to the tasks in
`planning_lab_revised(1).pdf`.

## Files

- `planner.py` — Python implementation and runnable tests for both planning domains.
- `planner.pl` — optional Prolog facts and rules for the verifier exercises.
- `solution.md` — worked answers, state traces, test results, and reflection answers.

## Requirements

- Python 3.8 or later. The planner uses only the Python standard library.
- Prolog is optional. To complete the optional extension, install SWI-Prolog.

## Run the Python planner

From this directory:

```bash
python3 planner.py
```

The program prints:
- initial applicability checks;
- the warehouse BFS plan and state trace;
- the no-plan result when pickup is removed;
- the irrelevant-action test;
- the locked-door BFS plan and state trace;
- the no-plan result when `PickKey` is removed;
- validation of the deliberately invalid locked-door sequence;
- independent validation of the BFS solution.

## Run the Prolog exercises

If SWI-Prolog is installed:

```bash
swipl -s planner.pl
```

At the `?-` prompt, try:

```prolog
can_move(a,b).
can_move(a,c).
valid_move(a,b).
valid_move(b,c).
valid_move(a,c).
reduce_speed.
```

Expected results:
- `can_move(a,b).` succeeds.
- `can_move(a,c).` fails because there is no direct `connected(a,c)` fact.
- `valid_move(a,b).` and `valid_move(b,c).` succeed.
- `valid_move(a,c).` fails.
- `reduce_speed.` succeeds by applying the two rules to `wet_road`.

## Submission note

The written solution is a worked reference. Review it, run the code yourself, and
adapt the reflection wording to accurately describe your own use of the LLM and
any changes you make before submitting.
