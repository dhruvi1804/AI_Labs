# Logical Planning Lab — Worked Solution

## Task 0 — Understand the planning problem

### (a) Initial state

`I = {At(Robot,A), At(Package,A)}`

The robot and package are both at location A. The robot is not holding the package.

### (b) Goal

`G = {At(Package,C)}`

The package, rather than merely the robot, must be at C.

### (c) Available actions

- `Move(A,B)`, `Move(B,A)`, `Move(B,C)`, `Move(C,B)`
- `PickUp(Package,A)`, `PickUp(Package,B)`, `PickUp(Package,C)`
- `Drop(Package,A)`, `Drop(Package,B)`, `Drop(Package,C)`

The Python implementation includes the movement actions and pickup actions needed
for the reachable warehouse states, and the `Drop(Package,C)` action needed to
achieve the goal.

### (d) Preconditions and effects

| Action | Preconditions | Positive effects | Negative effects |
|---|---|---|---|
| `Move(X,Y)` | `At(Robot,X)` | `At(Robot,Y)` | `At(Robot,X)` |
| `PickUp(Package,X)` | `At(Robot,X)`, `At(Package,X)` | `Holding(Package)` | `At(Package,X)` |
| `Drop(Package,X)` | `At(Robot,X)`, `Holding(Package)` | `At(Package,X)` | `Holding(Package)` |

`PickUp(Package,A)` is initially applicable because both of its preconditions
are true. `Drop(Package,C)` is not initially applicable because the robot is not
at C and is not holding the package.

## Task 1 — Construct a plan by hand

One valid plan is:

1. `PickUp(Package,A)`
2. `Move(A,B)`
3. `Move(B,C)`
4. `Drop(Package,C)`

State trace:

| State | Facts |
|---|---|
| S0 | `At(Robot,A)`, `At(Package,A)` |
| S1 | `At(Robot,A)`, `Holding(Package)` |
| S2 | `At(Robot,B)`, `Holding(Package)` |
| S3 | `At(Robot,C)`, `Holding(Package)` |
| S4 | `At(Robot,C)`, `At(Package,C)` |

The goal is true in S4.

## Task 2 — LLM prompt and implementation

### Prompt used

> Implement a simple planning agent in Python. Represent each state as a set of
> logical propositions. Represent each action with a name, positive preconditions,
> negative preconditions, positive effects, and negative effects. An action is
> applicable only when all positive preconditions are present and all negative
> preconditions are absent. Applying an action removes its negative effects and
> adds its positive effects. Use breadth-first search to find a sequence of
> actions that reaches a goal. Detect when no plan exists, print the action
> sequence, and print the states reached after each action. Explain assumptions.

### Where the specification appears

- Preconditions: `Action.applicable`.
- Effects: `Action.apply`.
- Goal test: `goal_set <= state` in `breadth_first_search`.
- BFS: the FIFO `deque` queue; states are expanded in breadth-first order.
- No-plan detection: the search returns `(None, None)` when the queue is empty.
- State trace: each successor state is appended to `trace`.

### Assumptions

- A state is a set of propositions; propositions not present are false.
- Actions have unit cost, so BFS finds a plan with the fewest actions.
- The goal is a conjunction of propositions; all goal propositions must be true.
- The finite domains in this lab are small enough for explicit state-space search.
- A visited-state set prevents repeated exploration of the same state.

## Task 3 — Test the generated planner

### Test A: Solvable warehouse problem

- Initial state: `{At(Robot,A), At(Package,A)}`
- Goal: `{At(Package,C)}`
- Plan found: yes.
- One shortest plan: `PickUp(Package,A)`, `Move(A,B)`, `Move(B,C)`,
  `Drop(Package,C)`.
- Validity: every action's preconditions are true when it is executed, and the
  final state contains `At(Package,C)`.

### Test B: Impossible problem

Remove all `PickUp` actions.

- Initial state: `{At(Robot,A), At(Package,A)}`
- Goal: `{At(Package,C)}`
- Plan found: no.
- Reason: the package begins at A and no remaining action can make the robot
  hold it or move the package. The planner reports `No plan found`.

### Test C: Irrelevant action

Add an action that moves the robot from A to B without changing the package's
location.

- Initial state: `{At(Robot,A), At(Package,A)}`
- Goal: `{At(Package,C)}`
- Plan found: yes, using the valid pickup, movement, and drop sequence.
- Validity: the planner checks the actual goal proposition
  `At(Package,C)`. Merely reaching `At(Robot,C)` is insufficient.

## Task 4 — Logic and search

Complete the flow as:

Current state → Check action preconditions → **If applicable, apply the action;
otherwise reject it** → Generate successor state → Search over alternatives → Goal?

Logical reasoning checks whether the propositions required by an action hold in
the current state and determines the result of applying its effects. Search
considers the different applicable actions and explores the resulting states
until a state satisfying the goal is found. Logic determines which transitions
are legal; search finds a sequence of legal transitions.

## Task 5 — Can the LLM verify its own plan?

The independently executed state transitions should be trusted more than an
LLM's explanation. The program explicitly checks preconditions and computes each
successor state according to the action effects. An LLM explanation can be
useful, but it may contain a reasoning or transcription error. Independent
execution provides a reproducible check of the proposed sequence.

## Task 6 — Locked-door planning domain

### (a) Shortest plan

A shortest plan is:

1. `PickKey`
2. `Move(A,B)`
3. `Unlock`
4. `Move(B,C)`

State trace:

| State | Facts |
|---|---|
| S0 | `At(A)`, `KeyAt(A)` |
| S1 | `At(A)`, `HasKey` |
| S2 | `At(B)`, `HasKey` |
| S3 | `At(B)`, `HasKey`, `Unlocked` |
| S4 | `At(C)`, `HasKey`, `Unlocked` |

### (b) BFS implementation

The six actions from the handout are encoded in `locked_door_actions()` in
`planner.py`. Running the program prints the BFS plan and state trace above.

### (c) Remove `PickKey`

No plan exists. `Unlock` requires both `At(B)` and `HasKey`, but without
`PickKey`, the proposition `HasKey` can never become true. Consequently,
`Unlocked` can never be established and `Move(B,C)` cannot be applied.

### (d) Validate the proposed sequence

Proposed sequence: `Move(A,B)`, `Unlock`, `Move(B,C)`.

The first action is valid and produces `{At(B), KeyAt(A)}`. The second action,
`Unlock`, is the first invalid action: its precondition `HasKey` is not
satisfied. The key is still at A and has not been picked up.

## Task 7 — Compare LLM plans across two domains

A suitable LLM prompt is:

> For the locked-door planning problem, find a plan using only these actions:
> `Move(A,B)`, `Move(B,A)`, `PickKey`, `Unlock`, `Move(B,C)`, and `Move(C,B)`.
> Initial state: `{At(A), KeyAt(A)}`. Goal: `{At(C)}`. Preconditions and effects
> are exactly those in the supplied action table. Return only the action sequence.

A valid shortest sequence is `PickKey`, `Move(A,B)`, `Unlock`, `Move(B,C)`.
The Python validator confirms that each action is applicable and that the final
state satisfies `At(C)`. Its length is four, matching BFS's shortest plan.
If an LLM proposes `Move(A,B), Unlock, Move(B,C)`, validation rejects it at
`Unlock` because `HasKey` is absent.

A plausible narrative does not guarantee validity: the validator checks the
actual preconditions in the state reached at each step. It can identify the
first illegal transition, which a fluent explanation may overlook.

## Task 8 — Prolog as a plan verifier

The file `planner.pl` contains the required facts and rules.

Expected query results:

| Query | Result | Explanation |
|---|---|---|
| `can_move(a,b).` | true | `connected(a,b)` is a fact, so the rule succeeds. |
| `can_move(a,c).` | false | There is no direct `connected(a,c)` fact. |

The rule `can_move(X,Y) :- connected(X,Y).` expresses the implication
`Connected(X,Y) → CanMove(X,Y)`: whenever the connected relation holds for
the two locations, the can-move relation can be inferred.

## Task 9 — Check a proposed plan with Prolog

Expected results:

- `valid_move(a,b).` succeeds.
- `valid_move(b,c).` succeeds.
- `valid_move(a,c).` fails.

The proposed `Move(a,c)` is unsupported because the knowledge base contains no
`connected(a,c)` fact. The Python planner can generate a candidate, while
Prolog independently checks whether each movement is supported by the
connectivity facts.

## Task 10 — Connect Prolog to logical reasoning

`reduce_speed` succeeds because the fact `wet_road` implies `slippery`, and
`slippery` implies `reduce_speed`.

Logical sequence:

`wet_road` (fact) ⇒ `slippery` (rule) ⇒ `reduce_speed` (rule).

## Reflection Questions (Section 6)

1. **Why specify preconditions and effects before asking an LLM to write the
   planner?**  
   They define exactly when actions are legal and how they change a state.
   This gives the implementation a precise specification and makes it easier
   to test correctness.

2. **Give an example of an error if preconditions are not checked.**  
   The planner might execute `Drop(Package,C)` while the robot is not at C or
   is not holding the package, producing an impossible state.

3. **Why is a reasonable-looking plan not necessarily valid?**  
   It may contain an action whose preconditions are false at the point where
   the action is executed, or it may finish without satisfying the actual goal.

4. **What did the LLM contribute to the implementation?**  
   It helped translate the planning specification into Python structures,
   action applicability/effect functions, BFS, and test scaffolding.

5. **What had to be verified independently?**  
   The action definitions, precondition checks, state updates, BFS result,
   no-plan cases, state traces, and whether the final state satisfies the goal.

6. **Where is logical reasoning used?**  
   It is used to test action preconditions and to infer the successor state
   from an action's positive and negative effects.

7. **How is planning related to search algorithms?**  
   Planning searches a state space. Each state is a node and each applicable
   action creates an edge to a successor state. BFS explores these states
   level by level to find a shortest plan when actions have equal cost.

## Reflection Questions (Section 8.2 — Prolog)

1. **Difference between a fact and a rule:**  
   A fact directly states that something is true, such as `wet_road.` A rule
   states that a conclusion is true when its conditions hold, such as
   `slippery :- wet_road.`

2. **How does a query correspond to a knowledge-base question?**  
   A query asks Prolog whether the requested goal can be derived from the
   available facts and rules.

3. **Why use Prolog to verify a Python-generated plan?**  
   Prolog provides a separate rule-based check of whether proposed actions are
   supported by the logical facts, helping detect unsupported transitions.

4. **What advantage does an independent verifier provide?**  
   It reduces reliance on the same implementation or LLM that generated the
   candidate. A separate check can expose errors that the generator overlooked.

## Overall reflection

The lab demonstrates that planning combines logical action modelling with
state-space search. The LLM can accelerate implementation, but its output is
not automatically correct. Explicit tests and an independent validator are
needed to establish that actions are applicable, state transitions are valid,
and the goal is actually reached.
